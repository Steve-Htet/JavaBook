package Generics;

import java.util.ArrayList;

public class Stack<T> {
	private ArrayList<T> stack;
	
	public Stack()
	{
		this(10);
	}
	public Stack(int capacity)
	{
		int size=capacity>0? capacity: 10;
		
		stack=new ArrayList<T>(size);
	}
	public T pop()
	{	if (stack.isEmpty()==true)
		throw new StackUnderFlowException();
		return stack.remove(stack.size()-1);
		
	}
	public void push(T element)
	{
		stack.add(element);
		
	}
	
	public static void main(String[] args) {
		Stack<Integer> stack1=new Stack<Integer>();
		stack1.push(34);
		stack1.push(56);
		stack1.push(66);
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());

	}

}
