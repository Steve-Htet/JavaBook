package Generics;

public class StackUnderFlowException extends RuntimeException{

	public StackUnderFlowException() {
		this("stack is empty");
	}
	public StackUnderFlowException(String msg) {
		super(msg);
	}
	
	

}
