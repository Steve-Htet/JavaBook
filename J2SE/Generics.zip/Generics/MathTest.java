
public class MathTest {

	
	public static void main(String[] args) throws ClassNotFoundException {
	
		System.out.println("Randome number");
		
		//int res=(int) Math.random();
		//System.out.println("res"+res);
		
		String classPath = System.getProperty("java.class.path",".");
		System.out.println(classPath);
		String classPath1 = System.getenv("javahome");
		System.out.println(classPath1);
		System.out.println(System.getProperties());
		System.out.println(System.getSecurityManager());
		System.out.println(Class.forName("MathTest"));
		String c="aabcd".substring(2,4);//substring 
		char[] data=new char[5];
	"abcde".getChars(0, 3, data, 0);
		System.out.println("data array length"+data.length+"data string");
		for(char ch:data)
		{
			
			System.out.println(ch);
		}
		
		String s1="axeayemyint";
		String s2="aungkyawmyint";
		String s3="aungkyawmyint";
		
		System.out.println("S1 and s2 comparison"+s1.compareTo(s2));
		System.out.println("S2 and s1 comparison"+s2.compareTo(s1));
		System.out.println("S2 and s3comparison"+s3.compareTo(s2));
		
	}

}
