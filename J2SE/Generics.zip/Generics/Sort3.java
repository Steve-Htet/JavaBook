package Generics;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ListIterator;

public class Sort3 {

	
	public static void main(String[] args) {
		
		ArrayList<Time2> lists=new ArrayList<Time2>();
		lists.add(new Time2(5,34,56));
		lists.add(new Time2(6,5,56));	
		lists.add(new Time2(7,3,56));
		lists.add(new Time2(3,22,56));
		lists.add(new Time2(2,34,56));
		Collections.sort(lists,new TimeComparator());
		ListIterator<Time2> iteraotr=lists.listIterator();
		while(iteraotr.hasNext())
		{	Time2 t2=iteraotr.next();
			System.out.println(t2.hour+"\t"+t2.minute+"\t"+t2.second);
		}

	}

}
