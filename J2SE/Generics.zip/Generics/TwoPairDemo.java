package Generics;

import java.util.Scanner;

public class TwoPairDemo {

	
	public static void main(String[] args) {
		TwoPair<String,Integer> firstPair=new TwoPair<String,Integer>("Henry",9);
		System.out.println(firstPair.getFirst()+"\t"+firstPair.getSecond());
		System.out.println("enter age of Henry ?");
		Scanner scanner=new Scanner(System.in);
		Integer i=scanner.nextInt();
		firstPair.setSecond(i);
		System.out.println(firstPair.getFirst()+"\t"+firstPair.getSecond());
		
	}

}
