package Generics;
/*Create a generic class named Rectangle which consists of the following fields and functions:
- width
- length

+ Constructor
+ setters
+ getters

Test your class with a variety of built-in types for fields (user input), such as Integer, String and Double. Display the results of the following methods. 

+ calculateArea

-area= width*length

+ calculatePerimeter

- perimeter= 2 * (width*length) */
public class Rectangle<T  extends Number> {
	T width;
	T length;
	

	public Rectangle(T w, T l) {
		width=w;
		length=l;
	}

	
	public T getWidth() {
		return width;
	}


	public void setWidth(T width) {
		this.width = width;
	}


	public T getLength() {
		return length;
	}


	public void setLength(T length) {
		this.length = length;
	}
	
	public void calculateArea()
	{	//T area;
		//double area;
		//area=getWidth().doubleValue()*getLength().doubleValue();
		//getWidth().
		//return area;
		if(width instanceof Integer && length instanceof Integer)
		{
		int	area=width.intValue()*length.intValue();
		System.out.println("area is"+area);
		}
		
		if(width instanceof Double && length instanceof Double)
		{
		double	area=width.doubleValue()*length.doubleValue();
		System.out.println("area is"+area);
		}
		if(width instanceof Float && length instanceof Float)
		{
		float	area=width.floatValue()*length.floatValue();
		System.out.println("area is"+area);
		}
		if(width instanceof Long && length instanceof Long)
		{
		long	area=width.longValue()*length.longValue();
		System.out.println("area is"+area);
		}
		
	}
	public double calculateArea2()
	{
		double area=width.doubleValue()*length.doubleValue();
		return area;
		
	}
	
	public void perimeter()
	{
		if(width instanceof Integer && length instanceof Integer)
		{
		int	pr=2*(width.intValue()+length.intValue());
		System.out.println("perimeter is"+pr);
		}
		
		if(width instanceof Double && length instanceof Double)
		{
		double	pr=2*(width.doubleValue()+length.doubleValue());
		System.out.println("perimeter is"+pr);
		}
		if(width instanceof Float && length instanceof Float)
		{
		float	pr=2*(width.floatValue()+length.floatValue());
		System.out.println("perimeter is"+pr);
		}
		
		
	}
	public static void main(String[] args) {
		
		Rectangle<Integer> r1=new Rectangle<Integer>(5,3);
		System.out.println(r1.calculateArea2());
		r1.perimeter();
		
		Rectangle<Double> r2=new Rectangle<Double>(5.5,3.6);
		System.out.println(r2.calculateArea2());
		r2.perimeter();
		
		
		
		

	}
	
	

}
