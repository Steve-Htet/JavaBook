package Generics;

public class Employee  {
	String name;
	int  age;
	double salary;
	
	

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	/*public boolean equals(Object obj)
	{
		if(obj ==null)
		{
			return false;
					
		}
		else if( obj.getClass()!=this.getClass())
			return false;
		
		else
		{	
		Employee obj1=(Employee)obj;
			return( (name.equals(obj1.name)) && (age==obj1.age)&& (salary==obj1.salary));
		}	
		*/
		
	}



	public Employee(String name, int age, double salary) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	
	
}
