package Generics;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

public class ArrayasList {

	public static void main(String[] args) {
		
		String[] colors={"red","green","blue"};
		System.out.println("original string arrays content"+colors.length);//original string arrays content
		for(String col:colors)
		{
			System.out.println(col);
		}
		LinkedList<String> linkedList=new LinkedList<String>(Arrays.asList(colors));
		linkedList.add("magenta");
		linkedList.addLast("purple");
		linkedList.addFirst("orange");
		linkedList.add(3, "gold");
		System.out.println("After list is modified,color arrays content\t"+colors.length+"list sizze\t"+linkedList.size());
		for(String col:colors)
		{
			System.out.println(col);
		}
		
		colors=linkedList.toArray(new String[linkedList.size()]);//does not change arrays after list was modified
		System.out.println("before color removed in List"+linkedList.size());
		for(String col:colors)
		{
			System.out.println(col);
		}
		System.out.println("before sort"+linkedList);
		Collections.sort(linkedList);
		System.out.println("afte sort"+linkedList);
		
		//linkedList.subList(3, 5).clear();
		/*
		System.out.println("after color removed in List"+linkedList.size());
		for(String col:colors)
		{
			System.out.println(col);
		}
		

	}
*/
}
}
