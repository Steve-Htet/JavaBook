import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class MouseMotionTest extends JFrame{
	private JPanel panel;
	private JLabel statusBar;
	
	
	
	

	public MouseMotionTest() {
		
		super("Mouse motion Test");
		panel=new JPanel();
		panel.setBackground(Color.white);
		statusBar =new JLabel("outside of the panel");
		add(panel,BorderLayout.CENTER);
		add(statusBar,BorderLayout.SOUTH);
		MouseHandler handler=new MouseHandler();
		panel.addMouseListener(handler);
		panel.addMouseMotionListener(handler);
		setSize(500,200);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	 class MouseHandler implements MouseListener ,MouseMotionListener{

			@Override
			public void mouseDragged(MouseEvent e) {
				statusBar.setText("drageed at"+e.getX()+e.getY());
				
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				statusBar.setText("moved at"+e.getX()+e.getY());
				
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				statusBar.setText("clicked at"+e.getX()+e.getY());
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				statusBar.setText("drageed at"+e.getX()+e.getY());
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				statusBar.setText("Released at"+e.getX()+e.getY());
				panel.setBackground(Color.GREEN);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				statusBar.setText("Entered at"+e.getX()+e.getY());
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				statusBar.setText("drageed at"+e.getX()+e.getY());
				panel.setBackground(Color.BLUE);
			}
			
			
			
			
		}
		


	public static void main(String[] args) {
		MouseMotionTest test=new MouseMotionTest();
	}

}
