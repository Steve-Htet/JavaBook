
public class MainClass{
	
	public static void main(String[] args)
	{
		class Ball{
			
			public void hit()
			{
				
				System.out.println("you hit it");
			}
			
			
			
		};
		new Ball().hit();
		
		/*interface Ball
		{
			void hit();
		}*/
		
	}
}
	
	
