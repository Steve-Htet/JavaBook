package Generics;

public class Sample<T extends Comparable>
{
	private T data;
	public void setData(T newData)
	{
	data=newData;
	}
	public T getData()
	{
		return data;
	}
}
