package Generics;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Lottery {
	private ArrayList<Student> students;
	
	public void addStudent()
	{	students=new ArrayList<Student>();
		Scanner input=new Scanner(System.in);
		String name="";
		System.out.println("Enter Student Name");
		name=input.next();
		
	do{
		System.out.println("ID");
		int id=input.nextInt();
		Student stu=new Student(name,id);
		System.out.println("student id"+stu.getId());
		if(stu.getId()!=0)
		{
			students.add(stu);
			System.out.println("student added");
		}
		else
			System.out.println(name+"not entered");
		//preparing for next input name
		//System.out.println(name+"not entered");
		System.out.println("Enter name for another student");
		name=input.next();
		
		
		
	}while(!name.equals("exit"));
		winnerPick();
	}
	public void winnerPick()
	{	int count=students.size();
		Random ran=new Random();
		
		Student winner=students.get(ran.nextInt(count));
		
		System.out.println("winner name"+winner.getName()+"winner id"+winner.getId());
		
		
		
	}

	
	public static void main(String[] args) {
		
		Lottery lot=new Lottery();
		lot.addStudent();
		

	}

}
