package Generics;

import java.util.Comparator;
public class TimeComparator implements Comparator{

	

	@Override
	public int compare(Object o1, Object o2) {
		Time2 t1=(Time2)o1;
		Time2 t2=(Time2)o2;
		int hr=t1.hour-t2.hour;
		if(hr!=0)
			return hr;
		int min=t1.minute-t2.minute;
		if(min!=0)
			return min;
		int sec=t1.second-t2.second;
		return sec;
	}

	
}
