package Generics;

public class Student {
	private String name;
	private int id;
	
	public String getName() {
		return name;
	}

	public Student()
	{
		name="";
		id=0;
		
	}
	public Student(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public boolean equals(Object st) {
		Student st1=(Student)st;
		return (this.name.equals(st1.name) && this.id==st1.id);
		
		
		
	}

	
	
}
