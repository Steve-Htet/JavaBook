
public class Buffer {

	public Buffer() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		StringBuffer vu=new StringBuffer("01234567");
		vu.delete(1,4);
		vu.deleteCharAt(0);
		System.out.println(vu);

	}

}
