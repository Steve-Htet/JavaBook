package Generics;

public class Gen<T>{
	private T ob;
	public Gen(T oj) {
		ob=oj;
	}

	
	public T getOb() {
		return ob;
	}


	public void setOb(T ob) {
		this.ob = ob;
	}


	public void showType()
	{
		
		System.out.println(ob.getClass().getName());
	}
	
	public static void main(String args[])
	{		System.out.println("for String");
			Gen<String> string=new Gen<String>("it is a string");
			System.out.println(string.getOb());
			string.showType();
			System.out.println();
			System.out.println("for Integer");
			Gen<Integer> integerr=new Gen<Integer>(99);
			System.out.println(integerr.getOb());
			integerr.showType();
		
	}
	
}
