import java.util.Random;


public class RandomTest {

	
	public static void main(String[] args) {
		
		int[] frequency=new int[10];//to storre frequency of number occurs
		Random r=new Random();
		for(int i=0;i<1000;i++)
		{
			int result=r.nextInt(10);
			//System.out.println(result);
			switch (result)
			{
			case 0:frequency[0]++;break;
			case 1:frequency[1]++;break;
			case 2:frequency[2]++;break;
			case 3:frequency[3]++;break;
			case 4:frequency[4]++;break;
			case 5:frequency[5]++;break;
			case 6:frequency[6]++;break;
			case 7:frequency[7]++;break;
			case 8:frequency[8]++;break;
			case 9:frequency[9]++;break;
			
			}
		}
		System.out.println("number"+"\t"+"frequency");
		for (int i=0;i<frequency.length;i++)
		{
			System.out.println(i+"\t"+frequency[i]);
			
		}

	}

}
