package Generics;

import java.util.Scanner;

public class Pair<T> {
	T first;
	T second;
	public Pair() {
		first=null;
		second=null;
	}

	public Pair(T f,T l) {
		first=f;
		second=l;
	}
	
	
	public T getFirst() {
		return first;
	}

	public void setFirst(T first) {
		this.first = first;
	}

	public T getSecond() {
		return second;
	}

	public void setSecond(T second) {
		this.second = second;
	}
	@Override
	public boolean equals(Object obj)
	{
		if(obj ==null)
		{
			return false;
					
		}
		else if( obj.getClass()!=this.getClass())
			return false;
		
		else
		{	Pair obj1=(Pair)obj;
			return (first.equals(obj1.first) && (second.equals(obj1.second)));
			
		}
		
	}
	public String toString()
	{
		return first.toString()+"\t"+second.toString();
		
	}

	public static void main(String[] args) {
		Pair<Integer> integers=new Pair<Integer>(44,55);
		Pair<Integer> integers1=new Pair<Integer>(44,55);
		System.out.println(	integers.equals(integers1));
		System.out.println(integers);
		//String implementation
		
		Pair<String> secrect=new Pair<String>("Be","Strong");
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("enter two words to guess");
		String first=scanner.next();
		String last=scanner.next();
		
		Pair<String> guess=new Pair<String>(first,last);
		
		if(secrect.equals(guess))
			System.out.println("Well Done,Your guess is correct");
		else
			
			System.out.println("you are wrong");
		
		
	}

}
