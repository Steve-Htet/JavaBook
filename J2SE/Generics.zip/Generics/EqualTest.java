package Generics;
/*2. Write a simple generic version of method isEqualTo that compares its two arguments and returns true
 *  if they are equal and false otherwise. Call this generic method in
 *  main method with a variety of built-in types, such as Integer, String and Double. */
public class EqualTest {

	public static <T extends Comparable> boolean EqualTest(T t1, T t2)
	{
		if ( t1.compareTo(t2)==0)
			return true;
		else return false;
		
		
	}

	
	public static void main(String[] args) {
		
	System.out.println(EqualTest(3,3));
	System.out.println(EqualTest(3.0,3.9));
	System.out.println(EqualTest("aa",""));

	}

}
