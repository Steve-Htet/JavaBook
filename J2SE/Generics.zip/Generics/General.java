package Generics;

public class General<T extends Employee> {
	T data;
	
	public General(T  data)
	{
		this.data=data;
		
	}
	
	public <T extends Employee>boolean equalTo(T e)
	
	
	
	{ 
		if(e instanceof Employee)
		
			return	(data.getName().equals(e.getName())&&data.getAge()==(e.getAge())&&data.getSalary()==(e.getSalary()));
		
		else return false;
		
		
		
	}
	public static void main(String args[])
	{
		General<Employee> g=new General<Employee>(new Employee("hla",45,56));
		General<Employee> g1=new General<Employee>(new Employee("hla",45,56));
		
		General<Employee> g2=new General<Employee>(new Employee("hnin",45,56));
		System.out.println("g and g1 is equal?"+g.equals(g1));
		System.out.println("g and g2 is equal?"+g.equals(g2));
	
		
		
	}
	

}
