package Generics;

public class Time2 {
	int hour;
	int minute;
	int second;
	public Time2(int hr,int min,int sec) {
		hour=hr;
		minute=min;
		second=sec;
	}

	public static void main(String[] args) {
		

	}

}
