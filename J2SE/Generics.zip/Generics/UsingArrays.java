package Generics;

import java.util.Arrays;

public class UsingArrays {
	private int[] intValues={5,6,87,67,55,87,66,454,5};
	private double[] doubleValues={67.0,55.6,77.8,88.5,88.9,76.8,8.7,7.0};
	private int[] filledInt;
	private double[] doubleCopy;
	
	public UsingArrays()
	{	filledInt=new int[7];
		Arrays.fill(filledInt, 7);
		doubleCopy=new double[doubleValues.length];
		System.arraycopy(doubleValues, 0, doubleCopy, 0, doubleValues.length);
		Arrays.sort(intValues);
		
		
		
	}
	public  void printArrays()
	{	for(int i=0;i<intValues.length;i++)
		{System.out.println(intValues[i]);
		
		}
		
	}
	
	public <T> int search(int num)
	{
		return Arrays.binarySearch(intValues, num);
	}


	
	public static void main(String[] args) 
	{
		UsingArrays array=new UsingArrays();
		array.printArrays();
		int i=array.search(5);
		System.out.println((i==1? "found":"not found"));

	}

}
