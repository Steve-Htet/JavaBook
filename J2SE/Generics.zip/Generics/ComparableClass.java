package Generics;

public class ComparableClass implements Comparable{

public int compareTo(Object o) {
	return 0;
}
public static void main(String args[]){
	Sample<ComparableClass> sc=new 	Sample<ComparableClass>();
	sc.setData(new ComparableClass());
	ComparableClass c=sc.getData();
	if(c==null) System.out.println("Null");
	else  
		{System.out.println("Not Null");
		System.out.println(c);
		
		}
	}

}
