
public class InternExample{
  public static void main(String[] args)
  {
		  String str1 = "Hello Java";
		  String str4=new String("Hello Java");
		  String str2 = new StringBuffer("Hello").append(" Java").toString();
		  String str3 = str4.intern();
		  String str5=str4.intern();
		  
		  
		  System.out.println("str1 == str2 " + (str1 == str2));
		  System.out.println("str5 == str3 " + (str5 == str3));
		  System.out.println(str3);
		  
  }
}