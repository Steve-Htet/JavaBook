
public class WrapperTest {

	
	public static void main(String[] args) {
		Integer x=56;
		int y=x;
		System.out.println("it is a wrapper value"+ x);
		System.out.println("it is a primitive value from wrapper value"+y);
		System.out.println("it is a max value"+ x.MAX_VALUE);
		System.out.println("it is a min tvalue"+ x.MIN_VALUE);
		System.out.println("it is using Integer.parseInt()"+ Integer.parseInt("456789"));
		System.out.println("it is using Integer.parseInt()with base 8\t"+ Integer.parseInt("127777",8));
		System.out.println("it is using Integer.parseInt()"+ Integer.toBinaryString(678));
		System.out.println("it is using to toHexString\t"+ Integer.toHexString(678));
		System.out.println("it is used only Double method tobinary"+Double.NaN );
		System.out.println("it is used only double constant netygative infini"+Double.NEGATIVE_INFINITY );
		System.out.println("it is used only Double constant positive infinity\t"+Double.POSITIVE_INFINITY );
		
		System.out.println("it is used only Integer method tobinary"+Double.isInfinite(678.00) );
		System.out.println("it is used only Integer method tobinary"+Double.valueOf("5445454.00"));
		System.out.println("it is maximum radix of Character"+Character.MAX_RADIX);
		System.out.println("it is mINIMUM radix of Character"+Character.MIN_RADIX);
		System.out.println("it is maximum VALUE of Character"+Character.MAX_VALUE);
		System.out.println("it is mINIMUM VALUE of Character"+Character.MIN_VALUE);
		System.out.println("it is mINIMUM  VRADIX Character"+Character.MIN_RADIX);
		System.out.println("it is maximum radix of Character"+Character.isLetter('A'));
		System.out.println("it is maximum radix of Character"+Character.isDigit('0'));
		System.out.println("it is maximum radix of Character"+Character.isLetterOrDigit('A'));
	
	}
}
