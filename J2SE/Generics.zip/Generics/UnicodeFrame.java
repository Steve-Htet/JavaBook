import javax.swing.JFrame;
import javax.swing.JLabel;


public class UnicodeFrame extends JFrame{

	public UnicodeFrame() {
		super("Demonstrationg");
	 JLabel label=new JLabel("\u1000\u1020\u1040"+"\u1030\u1050\u1097");
	 label.setToolTipText("it is myanmar lanaguage");
	 add(label);
	 setSize(200,100);
	 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 setVisible(true);
	}

	
	public static void main(String[] args) {
		UnicodeFrame frame=new UnicodeFrame();
		

	}

}
